#include "../../../../../src/corelib/tools/qtools_p.h"
