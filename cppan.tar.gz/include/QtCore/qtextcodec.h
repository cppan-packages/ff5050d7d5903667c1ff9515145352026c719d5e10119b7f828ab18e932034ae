#include "../../src/corelib/codecs/qtextcodec.h"
