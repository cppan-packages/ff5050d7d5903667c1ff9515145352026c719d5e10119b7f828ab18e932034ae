#include "../../src/corelib/io/qlockfile.h"
