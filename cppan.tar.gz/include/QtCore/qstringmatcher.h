#include "../../src/corelib/tools/qstringmatcher.h"
