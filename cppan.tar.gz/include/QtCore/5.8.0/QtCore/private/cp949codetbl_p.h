#include "../../../../../src/corelib/codecs/cp949codetbl_p.h"
