#include "../../src/corelib/global/qconfig-bootstrapped.h"
