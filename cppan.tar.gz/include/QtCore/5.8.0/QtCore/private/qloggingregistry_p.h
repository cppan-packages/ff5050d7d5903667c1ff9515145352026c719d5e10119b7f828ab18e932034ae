#include "../../../../../src/corelib/io/qloggingregistry_p.h"
