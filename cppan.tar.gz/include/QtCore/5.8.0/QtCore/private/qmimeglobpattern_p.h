#include "../../../../../src/corelib/mimetypes/qmimeglobpattern_p.h"
