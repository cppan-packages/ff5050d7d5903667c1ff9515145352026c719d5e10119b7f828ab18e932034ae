#include "../../../../../src/corelib/mimetypes/qmimeprovider_p.h"
