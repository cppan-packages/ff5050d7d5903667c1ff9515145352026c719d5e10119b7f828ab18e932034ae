#include "../../src/corelib/io/qtemporaryfile.h"
