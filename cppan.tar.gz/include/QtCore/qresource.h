#include "../../src/corelib/io/qresource.h"
