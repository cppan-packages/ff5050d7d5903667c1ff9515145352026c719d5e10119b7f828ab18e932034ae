#include "../../src/corelib/global/qglobalstatic.h"
