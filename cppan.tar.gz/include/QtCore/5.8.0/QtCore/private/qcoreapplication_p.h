#include "../../../../../src/corelib/kernel/qcoreapplication_p.h"
