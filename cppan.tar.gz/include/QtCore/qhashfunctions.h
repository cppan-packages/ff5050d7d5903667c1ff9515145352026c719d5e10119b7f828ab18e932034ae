#include "../../src/corelib/tools/qhashfunctions.h"
