#include "../../src/corelib/animation/qsequentialanimationgroup.h"
