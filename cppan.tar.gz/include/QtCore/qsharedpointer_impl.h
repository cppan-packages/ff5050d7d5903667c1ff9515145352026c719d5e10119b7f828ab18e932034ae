#include "../../src/corelib/tools/qsharedpointer_impl.h"
