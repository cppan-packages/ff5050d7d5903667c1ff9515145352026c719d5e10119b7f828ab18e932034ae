#include "../../src/corelib/arch/qatomic_msvc.h"
